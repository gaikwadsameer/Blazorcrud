# Repo for the YouTube tutorial "Blazor tutorial - CRUD app in ~30 minutes".
<br />
<br />
<br />
<h1> Link to video: https://youtu.be/bqp2JYjHn5g </h1>
